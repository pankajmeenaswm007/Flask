def where(condi={}):
    st=" where "
    i=1
    for key, value in condi.items():
        if(len(condi)==i):
            if(type(value)==int):
                st=st + key + " = " + str(value) + "  "
            else:
                st=st + key + " = '" + str(value) + "'  "
        else:
            if(type(value)==int):
                st=st + key + " = " + str(value) + " and  "
            else:
                st=st + key + " = '" + str(value) + "' and  "
        i=i+1
    return st


c={"email":"ram@yahoo.com","password":111,"xyz":"abc"}
print(where(c))