from flask import *
from lib import *
from item import *
from fileinput import filename

item=items()
ob=myclass()
app =Flask(__name__)
l=[]

@app.route("/")
def home():
      l=ob.getdata("user")
      return render_template("index.html",data=l)

# user delete database
@app.route("/userdelete/<un>")
def userdelete(un):
   ob.delete("user",un)
   return redirect("/")

# adminlogin page
@app.route("/admin")
def admin():
   return render_template("adminlogin.html")


# admin login
@app.route("/adminlogin",methods=["POST"])
def adminlogin():
   t=[]
   eml=request.form['xemail']
   psw=request.form['xpsw']
   t=ob.where("admin",eml)
   if(t[0][1]==eml and t[0][2]==psw):
      return render_template("index.html")
   else:
      return render_template("adminlogin.html",msg="Wrong User Details")
   
   # admin logout
@app.route("/logout")
def logout():
   return render_template("adminlogin.html")

# mens page
@app.route("/mens")
def mens():
   return render_template("men.html")

# womens page
@app.route("/womens")
def womens():
   return render_template("women.html")

# kids page
@app.route("/kids")
def kids():
   return render_template("kids.html")


# mens add data
@app.route("/menAdd",methods=["POST"])
def menAdd():
   img=request.files['xfile']
   brand=request.form['xbrand']
   title=request.form['xtitle']
   price=request.form['xprice']
   men=[]
   img.save("static/image/mens/"+img.filename)
   men=[img.filename,brand,title,price]
   item.insert("men",men)
   return redirect("/mens")

# womens add data
@app.route("/womenAdd",methods=["POST"])
def womenAdd():
   img=request.files['xfile']
   brand=request.form['xbrand']
   title=request.form['xtitle']
   price=request.form['xprice']
   women=[]
   img.save("static/image/women/"+img.filename)
   women=[img.filename,brand,title,price]
   item.insert("women",women)
   return render_template("women.html")


# kids add data
@app.route("/kidsAdd",methods=["POST"])
def kidsAdd():
   img=request.files['xfile']
   brand=request.form['xbrand']
   title=request.form['xtitle']
   price=request.form['xprice']
   kids=[]
   img.save("static/image/kids/"+img.filename)
   kids=[img.filename,brand,title,price]
   item.insert("kids",kids)
   return render_template("kids.html")


# Amenshow page
@app.route("/Amenshow")
def Amenshow():
   mens=[]
   mens=item.getdata("men")
   return render_template("Amenshow.html",data=mens)

# mendelete
@app.route("/mendelete/<un>")
def mendelete(un):
   item.delete("men",un)
   return redirect("/Amenshow")

# Awomenshow page
@app.route("/Awomenshow")
def Awomenshow():
   womens=[]
   womens=item.getdata("women")
   return render_template("Awomenshow.html",data=womens)

# womendelete
@app.route("/womendelete/<un>")
def womendelete(un):
   item.delete("women",un)
   return redirect("/Awomenshow")

# Akidsshow page
@app.route("/Akidsshow")
def Akidsshow():
   kids=[]
   kids=item.getdata("kids")
   return render_template("Akidsshow.html",data=kids)

# kidsdelete
@app.route("/kidsdelete/<un>")
def kidsdelete(un):
   item.delete("kids",un)
   return redirect("/Akidsshow")


if __name__ == '__main__':
   app.run(debug = True)
