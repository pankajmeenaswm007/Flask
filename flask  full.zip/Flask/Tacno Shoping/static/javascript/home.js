imgs=document.querySelectorAll("img");
imgs.forEach((img) => {
    img.addEventListener("click",()=>{
        alert("Please Login ")
    })
});