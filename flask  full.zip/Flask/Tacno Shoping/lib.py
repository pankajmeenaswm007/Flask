import mysql.connector

class myclass:

    def __init__(self):
##       object 
        self.mydb=mysql.connector.connect(host="localhost",user="root",password="",database="Tacno")
        

    def fire(self,qry):
        self.mycur=self.mydb.cursor()   ## object cursor set
        self.mycur.execute(qry)         ## cursor execute user query
        # return self.mycur

    def getdata(self,tab):   ##table show items
        # if(len(name)>=1):
            # qry="select * from " + tab + " where name ='" + name + "' "
        # else:
        qry="select * from " + tab + " "
        self.fire(qry)
        mydata=self.mycur.fetchall()
        return mydata
    
    def where(self,tab,mob):
        qry="select * from " + tab + " where email='" + mob + "' "
        self.fire(qry)
        mydata=self.mycur.fetchall()
        return mydata



    def insert(self,tab,data=[]):
##        table insert data
        qry="insert into "+tab+" set Name='"+data[0]+"',Mobile='"+str(data[1])+"' , Password='"+data[2]+"',Email='"+data[3]+"',file='"+data[4]+"' "
        self.fire(qry)       
        self.mydb.commit()
        return qry


    def delete(self,tab,id1):
##       table me row delete 
        qry="delete from "+tab+" where id="+str(id1)+""
        self.fire(qry)
        self.mydb.commit()
        # self.getdata(tab)

    def update(self,tab,eml,psw):
##      update table items  
        qry="update "+tab+" set Password='"+psw+"' where email='"+str(eml)+"'"
        print(qry)
        self.fire(qry)
        self.mydb.commit()
        # self.getdata(tab)

    def drop(self,tab):
##        qry="drop table "+tab+""  ## delete table
        qry="TRUNCATE table tab"    ## delete table all data and not delete structure
        print(qry)
        self.fire(qry)
        self.mydb.commit()

    def createTable(self,tab):
##     new table create   
        qry="create table "+tab+" (id int(10) primary key auto_increment,name varchar(255),city varchar(250),mobile int(10))"
        print(qry)
        self.fire(qry)
        self.mydb.commit()
        

    def rowcount(self):
        rc=self.mycur.rowcount
        return rc

    


