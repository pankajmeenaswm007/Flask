from flask import *
from lib import *
from item import *
from fileinput import filename
from flask_mail import *
import random 

ob=myclass()
item=items()
app =Flask(__name__)

l=[]
app.secret_key="xyz"
# start mail configuration
app.config['MAIL_SERVER']='smtp.gmail.com'
app.config['MAIL_PORT'] = 465
app.config['MAIL_USERNAME'] = 'saktibook@gmail.com'
app.config['MAIL_PASSWORD'] = 'bemrsvjbbthtgtlp'
app.config['MAIL_USE_TLS'] = False
app.config['MAIL_USE_SSL'] = True
mail = Mail(app)
# end configuration

@app.route("/")
def home():
   return render_template("home.html")

@app.route("/register")
def register():
   return render_template("register.html")

@app.route("/login")
def login():
   return render_template("login.html")

@app.route("/forget")
def forgt():
   return render_template("forget.html")


# user add
@app.route("/add", methods=["post"])
def add():
   l=ob.getdata("user")
   add=[]
   name=request.form["xname"]
   tel=request.form["xtel"]
   psw=request.form["xpsw"]
   eml=request.form["xemail"]
   img=request.files["xfile"]
   img.save("static/image/"+img.filename)
   add=[name,tel,psw,eml,img.filename]
    
   session['reg']=add
   temp=len(l)
   j=0
   for i in range(len(l)):
      j=j+1
      if(str(l[i][2])==str(tel)  ):
         return render_template("register.html",msg="Number is alerdy use please login")
      
      if(j==temp):
         session['otp']=otp=random.randint(111111,999999)
         msg=Message("Tacno registrastion" ,sender="saktibook@gmail.com" ,recipients=[eml])
         msg.body = "This OTP -> "+ str(otp) +" for Tacno registrastion Please do not share otp to anyone"
         mail.send(msg)
         return render_template("otp.html")
   return redirect("/")
      
# otp verify
@app.route("/otp",methods=["post"])
def otp():
   xotp=request.form["xotp"]
   add=[]
   add=session['reg']
   if(str(xotp)==str(session['otp'])):
      ob.insert("user",add)
      return render_template("login.html")
   else:
      return render_template("otp.html",msg="Wrong otp !!!!")
   return render_template('otp.html')

# user login
@app.route("/userlogin",methods=["POST"])
def userlogin():
   t=[]
   em=request.form['xemail']
   psw=request.form['xpsw']
   t=ob.where("user",em)
   for i in range(len(t)):
      if(t[i][4]==em and t[i][3]==psw):
         return render_template("ulogin.html",data=t[i])
      else:
         return render_template("login.html",msg="Wrong User Details")


#  user password forget
@app.route("/userforget",methods=["POST"])
def userforget():
   search=[]
   gmail=request.form['xemail']
   search=ob.where("user",gmail)
   session['forgeteml']=gmail
   ff=0

   for i in range(len(search)):
      if(search[i][4]==gmail):
         ff=ff+1
         session['forgetotp']=otp=random.randint(111111,999999)
         msg=Message("Tacno forget password" ,sender="saktibook@gmail.com" ,recipients=[gmail])
         msg.body = "This OTP -> "+ str(otp) +" for Tacno forget password Please do not share otp to anyone"
         mail.send(msg)
         return render_template("forgetpsw.html")
      
   if(ff==0):
         return render_template("forget.html",msg="Wrong User Details")


# user forgrt password otp verify
@app.route("/forgetpsw",methods=["POST"])
def forgetpsw():
   xotp=request.form["xotp"]
   xpsw=request.form["xpsw"]
   if(str(xotp)==str(session['forgetotp'])):
      ob.update("user",session['forgeteml'],xpsw)
      return render_template("forgetpsw.html",msg="password successful reset")
   else:
      return render_template("forgetpsw.html",msg="Wrong otp !!!!")
   

# user mens item show
@app.route("/Umenshow")
def umenshow():
   men=[]
   men=item.getdata("men")
   return render_template("Umenshow.html",data=men)


# user womens item show
@app.route("/Uwomenshow")
def uwomenshow():
   women=[]
   women=item.getdata("women")
   return render_template("Uwomenshow.html",data=women)

# user kids item show
@app.route("/Ukidsshow")
def ukidsshow():
   kids=[]
   kids=item.getdata("kids")
   return render_template("Ukidsshow.html",data=kids)


# buy page
@app.route("/buy/<un>")
def buy(un):
   mydata=un
   return render_template("buy.html",data=mydata)




if __name__ == '__main__':
   app.run(debug = True)
